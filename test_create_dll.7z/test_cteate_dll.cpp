#include <iostream>
#include "Dlltest.h"
using namespace std;

int main()
{
	cout << Add(9, 3) << endl;
	cout << Sub(9, 3) << endl;

	Dlltest dt;//ʵ��������
	cout << dt.Mul(9, 3) << endl;
	cout << dt.Div(9, 3) << endl;

	system("pause");
	return 0;
}