#include "pch.h"
#include "Dlltest.h"

int Add(int a, int b)
{
	return a + b;
}
int Sub(int a, int b)
{
	return a - b;
}
int Dlltest::Mul(int a, int b)
{
	return a * b;
}
int Dlltest::Div(int a, int b)
{
	return a / b;
}